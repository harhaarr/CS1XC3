/**
 * @file course.c
 * @author Ha Nguyen (nguyeh83@mcmaster.ca)
 * @brief This file contains the functions that are used for Course type
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Function enroll_student takes in type Course and Student then adds the students to that course
 * @brief The attribute total_student will be increased by 1 when a student is added
 * @brief It allocates the memory address using "calloc" if the student is the only one in the course
 * @brief It reallocates using "realloc" depends on the number students
 * @brief It then adds the student to the students attribute
 * 
 * @param Course type Course
 * @param Student type Student
 */ 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief the function takes in type Course and prints the Course's attributes
 * @brief it then prints the course's name, the course's code, and all students in that course
 * @param Course type Course
 * @return none
 */ 
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief the function top_student takes in type Course and return the student with highest average
 * @brief if there's no student in the course, it will return NULL
 * @param Course type Course
 * @return student* from type Student
 */ 
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief the function passing takes in type Course and the total number of passing students
 * @brief It uses the first for loop to check the number of students passing 
 * @brief Then it uses another for loop to add the students to the passing list
 * 
 * @param Course type Course
 * @param total_passing type Int
 * @return Student* from type Student
 * 
 */ 
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;

  //allocates the memory address to store the name of the students
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}