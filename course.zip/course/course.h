/**
 * @file course.h
 * @author Ha Nguyen (nguyeh83@mcmaster.ca)
 * @brief This file contains the functions that are used for Course type and typedef struct of Course
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief type Course stores name of the course and course code (both are array of characters), students (type Student), and total number of students (type Int)
 */ 
typedef struct _course 
{
  char name[100]; /**< the course name*/
  char code[10]; /**< the course code*/
  Student *students; /**< the student type*/
  int total_students; /**< the number of total students in the course*/
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);