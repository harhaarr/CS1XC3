/**
 * @file main.c
 * @author Ha Nguyen (nguyeh83@mcmaster.ca)
 * @brief This file runs the main function.
 * @brief It creates the type Course, then adds the students into the course and uses the functions that are written in course.c and student.c to print necessary information
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief the main function creates the course called Basics of Mathematics with the course code MATH101
 * @brief it then generates 20 random students and adds them to the list using enroll_student and generate_random_student
 * @brief the function then prints the course information using print_course, then uses top_student and pasing functions to print the top student and the number of passing students
 * @return int (type Int)
 */ 
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  //loops through the passing students list and print them
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);

  //return 0 since the function requires an output
  return 0;
}