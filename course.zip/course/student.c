/**
 * @file student.c
 * @author Ha Nguyen (nguyeh83@mcmaster.ca)
 * @brief This file contains the functions that are used for Student type
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief the function takes in Student type and grade of type Double then adds the grade to type Student
 * @brief The attribute num_grades will be increased by 1 when a grade is added
 * @brief It allocates the memory address using "calloc" if the student has only 1 grade
 * @brief It reallocates using "realloc" depends on the number of grades
 * 
 * @param student type Student
 * @param grade type double
 */ 
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief the function takes in type Student and calculate that student's average
 * @param student type Student
 * @return a number of type double, or 0 if the student doesn't have any grade
 */ 
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  //loops through student's grades and add them all up
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief the function prints student's information (name, ID, grades, average grade)
 * @param student type Student
 */ 
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** 
 * @brief the functions taking grades of int type and return a new student of type Student with a random first_name, last_name, and id.
 * @brief then it randomizes the grades for the new student
 * @param grades type Int
 * @return Student* of type Student
 */ 
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
  
//uses the add_grade function to add a random grade from 25 to 100
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}