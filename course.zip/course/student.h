/**
 * @file student.h
 * @author Ha Nguyen (nguyeh83@mcmaster.ca)
 * @brief This file contains the functions that are used for Student type and typedef struct of Student
 * @version 0.1
 * @date 2022-04-12
 * @copyright Copyright (c) 2022
 */

/**
 * @brief type Course stores first name and last name (both are array of characters), id (array of characters), grades (type double), num_grades (type Int)
 */ 

typedef struct _student 
{ 
  char first_name[50]; /**< the first name of the student*/
  char last_name[50]; /**< the last name of the student*/
  char id[11]; /**< Student ID*/
  double *grades; /**< the students' grades*/
  int num_grades; /**< the students' number of grades*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 